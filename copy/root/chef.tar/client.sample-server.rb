log_level        :info
log_location     STDOUT
chef_server_url  'http://yourchefserver.com:4000'
validation_client_name 'chef-validator'
