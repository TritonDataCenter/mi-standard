log_level        :info
log_location     STDOUT
chef_server_url  'https://api.opscode.com/organizations/ORGNAME'
validation_key         "/opt/local/etc/chef/ORGNAME-validator.pem"
validation_client_name 'ORGNAME-validator'
